# TP 1 - Ming Xiao Yuan (1949477) Charles Cassy (1947025)

Concernant les opérations de multiplication ou de division, d'addition ou de soustraction, il est impossible de les séparer pour définir la juste opération, A moins de mettre #ADDSOUS ou encore #MULTDIV pour la réduction de code. Nous avons suivi l'exemple fourni dans l'énoncé du tp.
